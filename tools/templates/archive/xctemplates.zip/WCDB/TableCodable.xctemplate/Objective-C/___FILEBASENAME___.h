//___FILEHEADER___

#import <Foundation/Foundation.h>

@interface ___VARIABLE_productName___ : NSObject

@property(nonatomic, retain) NSString *<#property1#>;
@property(nonatomic, assign) NSInteger <#property2#>;
@property(nonatomic, assign) float <#property3#>;
@property(nonatomic, strong) NSArray *<#property4#>;
@property(nonatomic, readonly) NSDate *<#..........#>;

@end
