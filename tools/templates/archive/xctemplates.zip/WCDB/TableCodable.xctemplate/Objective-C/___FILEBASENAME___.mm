//___FILEHEADER___

#import "___VARIABLE_productName___+WCTTableCoding.h"
#import "___VARIABLE_productName___.h"
#import <WCDB/WCDB.h>

@implementation ___VARIABLE_productName___

/*
WCDB_IMPLEMENTATION(___VARIABLE_productName___)
WCDB_SYNTHESIZE(___VARIABLE_productName___, <#property1#>)
WCDB_SYNTHESIZE(___VARIABLE_productName___, <#property2#>)
WCDB_SYNTHESIZE(___VARIABLE_productName___, <#property3#>)
WCDB_SYNTHESIZE(___VARIABLE_productName___, <#property4#>)
WCDB_SYNTHESIZE_COLUMN(___VARIABLE_productName___, <#property5#>, "<#column name#>")   // Custom column name

WCDB_PRIMARY_ASC_AUTO_INCREMENT(___VARIABLE_productName___, <#property#>)

WCDB_INDEX(___VARIABLE_productName___, <#property#>, <#_index_subfix#>)
 */

@end
