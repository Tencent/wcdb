//___FILEHEADER___

#import "___VARIABLE_productName___+WCTTableCoding.h"
#import "___VARIABLE_productName___.h"
#import <WCDB/WCDB.h>

@implementation ___VARIABLE_productName___

/*
WCDB_IMPLEMENTATION(___VARIABLE_productName___)
WCDB_SYNTHESIZE(<#property1#>)
WCDB_SYNTHESIZE(<#property2#>)
WCDB_SYNTHESIZE(<#property3#>)
WCDB_SYNTHESIZE(<#property4#>)
WCDB_SYNTHESIZE_COLUMN(<#property5#>, "<#column name#>")   // Custom column name

WCDB_PRIMARY_AUTO_INCREMENT(<#property#>)

WCDB_INDEX(<#_index_subfix#>, <#property#>)
 */

@end
