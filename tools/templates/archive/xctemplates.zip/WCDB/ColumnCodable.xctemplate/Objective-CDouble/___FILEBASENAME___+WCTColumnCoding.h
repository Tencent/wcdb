//___FILEHEADER___

#import "___VARIABLE_productName___.h"
#import <WCDB/WCDB.h>

@interface ___VARIABLE_productName___ (WCTColumnCoding) <WCTColumnCoding>

@end
