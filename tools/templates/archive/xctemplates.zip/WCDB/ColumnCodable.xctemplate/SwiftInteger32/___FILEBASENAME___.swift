//___FILEHEADER___

import Foundation
import WCDBSwift

class ___VARIABLE_productName___: WCDBSwift.ColumnCodable {
    typealias FundamentalType = Int32

    required init?(with value: Int32) {
        /* <#Init ___VARIABLE_productName___ From Int32#> */
    }

    func archivedValue() -> Int32? {
        return /* <#Archive ___VARIABLE_productName___ To Int32#> */
    }
}
