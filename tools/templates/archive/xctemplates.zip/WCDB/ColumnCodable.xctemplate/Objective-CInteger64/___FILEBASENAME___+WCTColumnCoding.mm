//___FILEHEADER___

#import "___VARIABLE_productName___+WCTColumnCoding.h"

@implementation ___VARIABLE_productName___ (WCTColumnCoding)

+ (instancetype)unarchiveWithWCTValue:(NSNumber *)value
{
    return /* <#Unarchive ___VARIABLE_productName___ From NSNumber *#> */;
}

- (NSNumber *)archivedWCTValue
{
    return /* <#Archive NSNumber * To ___VARIABLE_productName___#> */;
}

+ (WCTColumnType)columnTypeForWCDB
{
    return WCTColumnTypeInteger64;
}

@end
