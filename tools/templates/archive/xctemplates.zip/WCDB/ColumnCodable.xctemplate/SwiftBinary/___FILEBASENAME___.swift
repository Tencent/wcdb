//___FILEHEADER___

import Foundation
import WCDBSwift

class ___VARIABLE_productName___: WCDBSwift.ColumnCodable {
    typealias FundamentalType = Data

    required init?(with value: Data) {
        /* <#Init ___VARIABLE_productName___ From Data#> */
    }

    func archivedValue() -> Data? {
        return /* <#Archive ___VARIABLE_productName___ To Data#> */
    }
}
