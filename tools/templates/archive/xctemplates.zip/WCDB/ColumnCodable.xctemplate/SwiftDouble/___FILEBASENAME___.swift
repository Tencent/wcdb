//___FILEHEADER___

import Foundation
import WCDBSwift

class ___VARIABLE_productName___: WCDBSwift.ColumnCodable {
    typealias FundamentalType = Double

    required init?(with value: Double) {
        /* <#Init ___VARIABLE_productName___ From Double#> */
    }

    func archivedValue() -> Double? {
        return /* <#Archive ___VARIABLE_productName___ To Double#> */
    }
}
