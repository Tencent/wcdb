//___FILEHEADER___

import Foundation
import WCDBSwift

class ___VARIABLE_productName___: WCDBSwift.ColumnCodable {
    typealias FundamentalType = Int64

    required init?(with value: Int64) {
        /* <#Init ___VARIABLE_productName___ From Int64#> */
    }

    func archivedValue() -> Int64? {
        return /* <#Archive ___VARIABLE_productName___ To Int64#> */
    }
}
