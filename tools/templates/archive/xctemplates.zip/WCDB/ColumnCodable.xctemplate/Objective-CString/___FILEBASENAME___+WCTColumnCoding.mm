//___FILEHEADER___

#import "___VARIABLE_productName___+WCTColumnCoding.h"

@implementation ___VARIABLE_productName___ (WCTColumnCoding)

+ (instancetype)unarchiveWithWCTValue:(NSString *)value
{
    return /* <#Unarchive ___VARIABLE_productName___ From NSString *#> */;
}

- (NSString *)archivedWCTValue
{
    return /* <#Archive NSString * To ___VARIABLE_productName___#> */;
}

+ (WCTColumnType)columnTypeForWCDB
{
    return WCTColumnTypeString;
}

@end
