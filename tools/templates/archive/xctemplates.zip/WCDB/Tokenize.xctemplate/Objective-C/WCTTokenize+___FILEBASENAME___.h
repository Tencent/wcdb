//___FILEHEADER___

#import <Foundation/Foundation.h>
#import <WCDB/WCTMacroHelper.h>

WCDB_EXTERN NSString *const WCTTokenizerName___VARIABLE_productName___;
